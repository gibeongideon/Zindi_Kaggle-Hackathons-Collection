#!/usr/bin/env python
# coding: utf-8

# In[1]:


from selenium import webdriver
#from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from time import sleep
import pandas as pd
import re
import datetime
#import datetime
options = Options()
options.add_argument('--headless')
options.add_argument('--no-sandbox')
#options.add_argument("window-size=1400,600")
#options.add_argument('--disable-gpu')  # for windows
#page= driver.execute_script("return document.body.innerHTML")

from bs4 import BeautifulSoup



# In[ ]:





# In[ ]:





# In[2]:



def rL2(pL):
    pattern  = re.compile(r'\bFinal\b', re.I)

    for val in pL:
        bl = bool(pattern.search(val))
        if bl is True:
            

            index = pL.index(val)

            k1=pL[index]+pL[index+1]
            v1=float(pL[index+2])

            k2=pL[index]+pL[index+3]
            v2=float(pL[index+4])

            k3=pL[index]+pL[index+5]
            v3=float(pL[index+6])

                #half time results
            k11=pL[index+7]+pL[index+8]
            v11=float(pL[index+9])

            k22=pL[index+7]+pL[index+10]
            v22=float(pL[index+11])

            k33=pL[index+7]+pL[index+12]
            v33=float(pL[index+13])
            
            


        pattern_05  = re.compile(r'\bgoals\b\s\(0.5', re.I)
    # for val in pL:
        bl05 = bool(pattern_05.search(val))
        if bl05 is True:
            index_05 = pL.index(val)

            kov05=  pL[index_05]+pL[index_05+1] 
            von05=float(pL[index_05+2])

            kuv05=pL[index_05]+pL[index_05+3]
            vun05=float(pL[index_05+4])


        elif bl05 is False:
            try:
                kov05
            except:

                kov05='Total goals (0.5)over'
                von05=0

                kuv05='Total goals (0.5)under'
                vun05=0

        pattern_15  = re.compile(r'\bgoals\b\s\(1.5', re.I)
    # for val in pL:
        bl15 = bool(pattern_15.search(val))
        if bl15 is True:

            index_15 = pL.index(val)

            #kov25=  'Total goals (1.5)over'  #[index_5]: ##
            kov15=  pL[index_15]+pL[index_15+1]
            von15=float(pL[index_15+2])

            kuv15=pL[index_15]+pL[index_15+3]
            vun15=pL[index_15+4]  ######ERRR


        elif bl15 is False:
            try:
                kov15
            except:

                        #over/Under 1.5
                kov15='Total goals (1.5)over'
                von15=0

                kuv15='Total goals (1.5)under'
                vun15=0

        pattern_25  = re.compile(r'\bgoals\b\s\(2.5', re.I)
    # for val in pL:
        bl25 = bool(pattern_25.search(val))
        if bl25 is True:

            index_25 = pL.index(val)

            kov25=  pL[index_25]+pL[index_25+1]
            von25=float(pL[index_25+2])

            kuv25=pL[index_25]+pL[index_25+3]
            vun25=float(pL[index_25+4])


        elif bl25 is False:
            try:
                kov25
            except:

                        #over/Under 1.5
                kov25='Total goals (2.5)over'
                von25=0

                kuv25='Total goals (2.5)under'
                vun25=0

        pattern_35  = re.compile(r'\bgoals\b\s\(3.5', re.I)
    # for val in pL:
        bl35 = bool(pattern_35.search(val))
        if bl35 is True:

            index_35 = pL.index(val)
            #kov35=  'Total goals (2.5)over'  #[index_5]: ##
            kov35=  pL[index_35]+pL[index_35+1]
            von35=float(pL[index_35+2])

            kuv35=pL[index_35]+pL[index_35+3]
            vun35=float(pL[index_35+4])


        elif bl35 is False:
            try:
                kov35
            except:

                        #over/Under 1.5
                kov35='Total goals (3.5)over'
                von35=0

                kuv35='Total goals (3.5)under'
                vun35=0      

                ######


        pattern_45  = re.compile(r'\bgoals\b\s\(4.5', re.I)
    # for val in pL:
        bl45 = bool(pattern_45.search(val))
        if bl45 is True:

            index_45 = pL.index(val)
           
            #kov45=  'Total goals (2.5)over'  #[index_5]: ##
            kov45=  pL[index_45]+pL[index_45+1]
            von45=float(pL[index_45+2])

            kuv45=pL[index_45]+pL[index_45+3]
            vun45=float(pL[index_45+4])


        elif bl45 is False:
            try:
                kov45
            except:

                        #over/Under 1.5
                kov45='Total goals (4.5)over'
                von45=0

                kuv45='Total goals (4.5)under'
                vun45=0 



        pattern_score  = re.compile(r'\bscore\b', re.I)

    # for val in pL:
        bl_s = bool(pattern_score.search(val))
        if bl_s is True:

            index_s = pL.index(val)
            #  first to score

            fk11=pL[index_s]+pL[index_s+1]
            fv11=float(pL[index_s+2])

            fk22=pL[index_s]+pL[index_s+3]
            fv22=float(pL[index_s+4])

            fk33=pL[index_s]+pL[index_s+5]
            fv33=float(pL[index_s+6])    

        elif bl_s is False:

                pass



        tName='TIME'
        tValue=pL[-2]
        tmName='TEAMS'
        tmValue=pL[-1]

        T='tIMEsTAMP'
        d=datetime.datetime.now()
        T2='tIMEsTAMP2'
        d2=datetime.datetime.now().strftime('%a %H:%M')

        T3='tIMEsTAMP3'
        d3=datetime.datetime.now().strftime('%a' ' ' '%d')

    RK='ALL RECORDS'
    RV=pL[:]

    rDic={k1:v1,k2:v2,k3:v3,k11:v11,k22:v22,k33:v33,kov05:von05,kuv05:vun05,kov15:von15,kuv15:vun15,kov25:von25,
          kuv25:vun25,kuv35:vun35,kov35:von35,kuv45:vun45,kov45:von45,fk11:fv11,fk22:fv22,fk33:fv33,
             tName:tValue,tmName:tmValue,T:d,T2:d2,T3:d3}

    rDic2={RK:RV}

    return rDic,rDic2


# In[3]:


#____________________________________________________________________________________________
def countD(n,str1="Next job in {} S"):
    countDown = n
    while (countDown >= 0):
        cc=[]
        if countDown != 0:
            cc.append(countDown)
            print(f'Resume in: {cc[0]}',end='\r')
            sleep(1)
            cc.clear()
            countDown = countDown - 1
        else:
            break


# In[4]:


def lData(pageSource,driver):
    table = pd.read_html(pageSource)
   # print(table)
#     try:

    soup = BeautifulSoup(pageSource, 'html.parser')
    nu =soup.find("th", class_="sport-name")
    rnd =nu.text.strip()
    rr =re.findall(r'\d+', rnd)
    rounds =int(rr[0])
#     except:
#         pass


    try:

        table = pd.read_html(pageSource)
        fList=[]
        fList2=[]
        for n in range(0,15,2):
            x=[table[0].iloc[:, 0][n],table[0].iloc[:, 1][n]]
           # print(f'x: {x}')

            y=(table[0].iloc[:, 0][n+1])
           # print(f'y: {y}')



           # String1=y#.replace(',','.')
            rev_y = re.sub(r'\s\s', ",", y).split(",")
            Rev=rev_y+x



            d,d2=rL2(Rev)
            #print(d)
            d['round'] = rounds  # add round to dict 

            fList.append(d)
            fList2.append(d2)

    

        dF=pd.DataFrame(fList)
        dF2=pd.DataFrame(fList2)

        DF=dF.fillna(0)  
        DF2=dF2.fillna(0)

        with open('/home/gibeon/Desktop/Mozzart/Storage/ODDS/mOddData.csv', 'a') as f:
            DF.to_csv(f, index=False, header=False)
        #del fList[:]
        fList.clear()
        with open('/home/gibeon/Desktop/Mozzart/Storage/ODDS/mOddDataRaw.csv', 'a') as f:
            DF2.to_csv(f, index=False, header=False)
        #del fList[:]
        fList.clear()
        fList2.clear()
        print('\r')
        print('Data saving DONE!....')
        driver.close()

    except:
        #print('Failed! Retrying in {}  seconds'.format(cc[0]),end='\r')
        driver.close()
        sleep(3)
        pass
       # fail_save()

def reload():
        
      #  try:
        print('loading page...',end='\r')
        sleep(2)
        driver = webdriver.Chrome(executable_path="/home/gibeon/Desktop/my/chromedriver",options=options)
        sleep(1)
        driver.get("https://www.mozzartbet.co.ke/en/virtual-games/vfl")
        #driver.get("https://www.mozzartbet.com/en/virtual-games/vfl#/")

        sleep(3)

        print('Loading complete!',end ='\r')
        pageSource=(driver.page_source).encode('utf-8')

        return pageSource ,driver
#         except :
#             print('internet issue')
#             driver.close()
#             pass
# #         print(pageSource)
# #         d
# #         sleep(2)
#         #lData(pageSource,driver)
        


# In[ ]:





# In[5]:




count=0
while True:
    count=count+1
    print(f'Mining data No: {count}')
    

    #options = Options()
    #options.add_argument('--headless')
    
    try:
        
        try:
            page ,driver =reload()
            lData(page ,driver)

        except Exception as e: 
            print(e)  
            driver.close()
            print('retry',end ='')
            sleep(30)
            page ,driver =reload()
            lData(page ,driver)
            
            
        
    except Exception as e:
        print(e)
        
        driver.close()
        
        print('Big err')
        pass
    

    countD(250)
    
    


# In[ ]:




